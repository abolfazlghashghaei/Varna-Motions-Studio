/* Interface localization only. Project content, media names and native identifiers are never translated. */
(function(w){'use strict';const dictionary=Object.fromEntries(`
ویرایش|Edit
زمان‌بندی|Timing
کلمه‌ها|Words
طرح‌های آماده|Presets
خطوط|Dividers
مدل|Model
منبع|Source
دستهٔ تنظیمات|Settings category
قلم|Font
جای‌گذاری|Position
جلوه‌ها|Effects
کپشن‌ها|Captions
جمله‌بندی|Sentences
ساخت موشن|Custom motion
سطح پیوسته|Continuous surface
سطح|Surface
ساختار|Structure
محتوا|Content
تراز|Alignment
فونت|Font
انتخاب فونت متن|Choose text font
انتخاب فونت خانه|Choose cell font
ماتی نوارها · ٪|Toolbar opacity · %
سطح پیوسته بین کپشن‌ها|Continuous surface between captions
مدت تغییر اندازه · ثانیه|Resize duration · seconds
منحنی تغییر اندازه|Resize curve
فاصلهٔ قابل اتصال · ثانیه|Maximum connecting gap · seconds
انیمیشن نمونه|Motion sample
نمونهٔ حرکت سطح پیوسته|Continuous surface motion sample
فریم واقعی افتر|Capture AE frame
فریم واقعی کامپوزیشن افتر|Captured AE composition frame
کشسان|Elastic
خطی|Linear
ابزارها|Tools
جست‌وجوی ابزار|Search tools
آهنربای مرکز و لبه‌ها · Alt برای حرکت آزاد|Snap to center & edges · hold Alt to bypass
صفحه‌های تنظیمات جدول|Table settings pages
بخش تنظیمات|Settings section
خط‌مشی جمله‌بندی|Sentence grouping policy
ابتدا متن وارد کن.|Import text first.
ابتدا جمله‌بندی را خاموش کن؛ سپس بازسازی را بزن.|Disable sentence grouping before rebuilding.
مرزبندی با نشانه‌گذاری و مکث اعمال شد؛ گرامر یا واژگان بازنویسی نشد.|Boundaries use punctuation and pauses; grammar and vocabulary are unchanged.
نسخهٔ اصلی برگشت؛ ویرایش نسخهٔ جمله‌بندی‌شده حفظ شد.|Original restored; edits to the segmented version are retained.
متن اصلی تغییر کرده؛ برای حفظ ویرایش‌ها، «بازسازی از نسخهٔ اصلی» را بزن.|The original changed. Use Rebuild from original to regenerate the edited branch explicitly.
نمونهٔ صدا؛ پیش‌نمایش خودکار افتر بی‌صداست.|Sound sample; automatic AE visual previews remain silent.
صدا با تایم ورود در خروجی ساخته می‌شود.|Entry sound will be included in final output.
صدای ورود خاموش شد.|Entry sound disabled.
تایپ روی کامپوزیشن افتر آماده است؛ با پخش تایم‌لاین ببین.|Typewriter is ready in the AE composition. Play the timeline to view it.
فونت و رنگ|Font & color
تایپوگرافی کلمه‌ای|Word typography
استایل‌ها و قالب‌ها|Styles & templates
موشن آماده و شخصی|Stock & custom motion
ارسال متن خانه‌ها به افتر|Send cell text to AE
فونت کل جدول|Table font
ورود حرفه‌ای جدول|Table entrance preset
فنری نرم · الهام از iOS|Soft spring · iOS inspired
آبشاری · الهام از Material|Cascade · Material inspired
شناور سینمایی|Cinematic float
کشش سطح مشترک|Shared surface stretch
تنظیم دستی|Manual settings
منحنی کلیدهای جدول|Table keyframe curve
خروج جدول|Table exit
جمع‌شدن نرم|Soft shrink
پایین‌رفتن|Drop
مدت خروج · ثانیه|Exit duration · seconds
نرم|Smooth
شناور|Float
سریع و قاطع|Snappy
خطی|Linear
پیش‌نمایش افتر|AE preview
ساخت جدول|Build table
پیش‌نمایش زنده|Live preview
کنترل‌های پیش‌نمایش و فریم افتر|Preview & AE frame options
تنظیمات جدول|Table settings
بخش تنظیمات جدول|Table settings page
جمله‌بندی آفلاین · حفظ نسخهٔ اصلی|Offline segmentation · keep original
حد واژه در هر بخش|Words per segment
مکث مرزی · ثانیه|Boundary pause · seconds
بازسازی از نسخهٔ اصلی|Rebuild from original
به‌روزرسانی متن در افتر|Text update in After Effects
پس از مکث در نوشتن|After a typing pause
پس از خروج از کادر متن|After leaving the text field
صدای ورود متن|Text entry sound
صدای ورود متن خانه‌ها|Table cell entry sound
صدای ورود روشن باشد|Enable entry sound
حس صدا|Sound character
نرم · Soft|Soft
پاپ · Pop|Pop
هوا · Air|Air
زنگ نرم · Chime|Chime
شدت · dB|Level · dB
جای صدا|Cue placement
یک بار با ورود کپشن|Once at caption entry
با زمان ورود هر کلمه · حداکثر ۶۴|At each word entry · up to 64
شنیدن نمونه|Listen
اعمال به محدودهٔ موشن|Apply to motion scope
شیشهٔ نرم|Soft glass
رنگ ساده|Solid color
رنگ حجمی + شیشه|Volumetric color + glass
حرکت بک‌گراند|Background motion
شیشه|Glass
تحریری|Editorial
پخش|Broadcast
مینیمال|Minimal
درخشان|Neon
شخصی|Personal
تنظیمات همین کلمه|Selected word settings
دستهٔ تنظیمات کلمه|Word settings category
ظاهر و موقعیت|Appearance & position
فاصلهٔ حروف و دورخط|Tracking & stroke
ورود و خروج متن|Text entrance & exit
فاصلهٔ حروف|Tracking
فاصلهٔ سطرها|Leading
استودیوی ویدیو|Video Studio
رسانه · تدوین · گرافیک · خروجی|Media · edit · graphics · export
لایه‌ها، کی‌فریم و متریال|Layers, keyframes & materials
شروع|Home
شروع وارنا|Home
متن وارنا|Text
بک‌گراند وارنا|Background
جدول وارنا|Table
تدوین وارنا|Video
صدای وارنا|Audio
برند وارنا|Brand
سیستم وارنا|Settings
درباره و مجوزها|About & licenses
درباره و اطلاعات|About & licenses
موشن استودیو|Motion Studio
نمایش|View
پیش‌نمایش|Preview
خروجی AE|Build in AE
برگشت|Back
خانه|Home
برند|Brand
بدون برند|No brand
جدید|New
بازکردن|Open
ذخیره|Save
حذف|Delete
بستن|Close
انصراف|Cancel
تأیید|Confirm
اعمال|Apply
اجرا|Run
توقف|Stop
ادامه|Continue
انتخاب|Select
انتخاب همه|Select all
همه|All
همین کپشن|Selected caption
همهٔ کپشن‌ها|All captions
کپشن فعلی|Current caption
مرحلهٔ قبل|Previous step
مرحلهٔ بعد|Next step
مدل و ورود|Model & source
مدل متن|Text model
منبع و ساخت متن|Source & transcription
وضعیت و گزارش|Status & logs
اصلاح|Review
متن و زمان|Text & timing
اصلاح و حافظه|Corrections & memory
مدل اصلاح|Correction model
ترجمه|Translation
موشن|Motion
ظاهر متن|Text appearance
چیدمان|Layout
تایپ|Typewriter
تایپوگرافی|Typography
کلمات مهم|Highlights
قالب‌ها|Templates
موشن شخصی|Custom motion
ابزارهای افزوده|Extra tools
بک‌گراند|Background
متریال|Material
هندسه|Geometry
رنگ و دورخط|Color & border
اپتیک|Optics
ورود و خروج|In & out
جلوه‌های افزوده|Extra effects
بررسی و ساخت|Review & build
خروجی|Export
محدودهٔ امن|Safe area
انتخاب متن|Select text
متن و مقصد|Text & destination
سطح و استایل|Surface & style
ابعاد و گردی|Size & corners
رنگ و اپتیک|Color & optics
حرکت|Animation
ساختار|Structure
ردیف و ستون|Rows & columns
محتوا|Content
خانه‌ها|Cells
ظاهر|Appearance
سطح و خطوط|Surface & lines
زمان و حرکت|Timing & motion
ورود و حضور|Entrance & hold
کامپوزیشن|Composition
پروژه|Project
مقصد ویدیو|Video destination
رسانه|Media
رسانه‌ها|Media
فایل‌ها|Files
برداشت‌ها|Shots
انتخاب شات|Select shots
تایم‌لاین|Timeline
تدوین|Edit
بررسی|Review
منبع و مدل|Source & model
مدل‌ها|Models
تولید|Generate
موسیقی و افکت صوتی|Music & sound effects
کتابخانه|Library
فایل‌های صوتی|Audio files
هماهنگی|Sync
تحلیل و جای‌گذاری|Analyze & place
تراز و بررسی|Mix & review
تراز صدا|Audio balance
برندها|Brands
هویت|Identity
ظاهر برند|Brand style
دارایی‌ها|Assets
لوگو و فایل‌ها|Logo & media
اعمال و بررسی|Apply & review
اتصال|Connection
اتصال و چیدمان|Connection & layout
منابع سیستم|System resources
پروفایل|Profile
ذخیره و بازیابی|Save & restore
تحلیل پروژه|Analyze project
استودیوی تدوین|Video Studio
استودیوی تدوین وارنا|Video Studio
حالت حرفه‌ای|Professional mode
حالت معمول|Regular mode
ابزارهای وارنا|Tools
میان‌برها|Shortcuts
تمام‌صفحه|Fullscreen
پنجره مستقل|Separate window
سازگاری میزبان‌ها|Host support
گرافیک و موشن|Graphics & motion
＋ عنوان|＋ Title
＋ شیپ|＋ Shape
＋ جدول|＋ Table
نام لایه|Layer name
عرض شیپ|Shape width
ارتفاع شیپ|Shape height
رنگ اول|First color
رنگ دوم|Second color
رنگ دورخط|Border color
ضخامت دورخط|Border width
ماتی شیشه|Glass blur
شدت شیشه|Glass tint
مدت ورود|Entrance duration
رنگ جداکننده|Divider color
ضخامت جداکننده|Divider width
فاصلهٔ متن|Text padding
تراز عمودی|Vertical alignment
نمایش لایه|Show layer
پنهان‌کردن لایه|Hide layer
حذف لایه|Delete layer
کی‌فریم و منحنی|Keyframes & curves
ویژگی|Property
منحنی|Curve
ثبت کی‌فریم در پلی‌هد|Add keyframe at playhead
خروجی شفاف برای میزبان‌ها|Transparent graphics export
Text+ قابل ویرایش برای Resolve|Editable Text+ for Resolve
جدول فعلی پلاگین|Import panel table
چرخش|Rotation
محو ورود تصویر|Video fade in
محو خروج تصویر|Video fade out
ماسک|Mask
بدون ماسک|No mask
بیضی|Ellipse
ترکیب|Blend mode
نوردهی EV|Exposure EV
ماتی|Blur
＋ ورود فایل|＋ Import media
اتصال فایل|Relink media
جست‌وجوی رسانه|Search media
نام پروژه|Project name
پخش یا مکث|Play / pause
ابتدای پروژه|Project start
پلی‌هد|Playhead
برش|Split
کپی کلیپ|Duplicate clip
＋ تصویر|＋ Video track
＋ صدا|＋ Audio track
چسبندگی|Snapping
بستن فاصله پس از حذف|Ripple delete
بزرگ‌نمایی تایم‌لاین|Timeline zoom
زیرنویس|Captions
رنگ و نور|Color
صدا|Audio
رسانه و پروژه|Media & project
تنظیمات کلیپ|Clip inspector
زیرنویس و تایپوگرافی|Captions & typography
میکس صدا|Audio mix
آمادهٔ خروجی|Delivery
عرض|Width
ارتفاع|Height
فریم‌ بر ثانیه|Frame rate
افقی / عمودی|Landscape / portrait
ورود زیرنویس SRT|Import SRT captions
فونت از فایل|Load font file
تنظیم موتور محلی|Local engine settings
خروجی ویدیو|Export video
خروجی زیرنویس SRT|Export SRT captions
ذخیره پروژهٔ قابل ویرایش|Save editable project
＋ متن|＋ Caption
تشخیص گفتار|Transcribe
خواندن متن و استایل‌های وارنا|Read panel text & styles
برگرداندن به متن وارنا|Send titles to panel
متن زیرنویس|Caption text
شروع · ثانیه|Start · seconds
پایان · ثانیه|End · seconds
کل عبارت|Entire caption
عبارت|Caption
واژهٔ انتخابی|Selected word
استایل عبارت|Caption style
استایل واژهٔ انتخابی|Selected word style
انتخاب استایل|Choose a style
فونت|Font
اندازه|Size
رنگ متن|Text color
رنگ زمینه|Background color
افقی ٪|Horizontal %
عمودی ٪|Vertical %
شفافیت زمینه|Background opacity
گردی|Corner radius
ورود|Entrance
بدون حرکت|None
محو|Fade
بالا آمدن|Rise
کناری|Slide
پاپ|Pop
فنری|Spring
تراز متن|Text alignment
چپ|Left
وسط|Center
راست|Right
بالا|Top
پایین|Bottom
حذف زمینه|Remove background
نقطه ورود منبع|Source in
نقطه خروج منبع|Source out
جابه‌جایی افقی ٪|Position X %
جابه‌جایی عمودی ٪|Position Y %
بزرگ‌نمایی ٪|Scale %
شفافیت|Opacity
قرارگیری|Fit
کامل در کادر|Contain
پرکردن کادر|Cover
نور|Brightness
کنتراست|Contrast
اشباع|Saturation
چرخش رنگ|Hue
طبیعی|Natural
سینمایی|Cinematic
گرم|Warm
سیاه‌وسفید|Monochrome
شدت صدا · ۱ = عادی|Gain · 1 = unity
Fade In · ثانیه|Fade in · seconds
Fade Out · ثانیه|Fade out · seconds
استودیوی ساخت صدا|Sound studio
موتور محلی|Local engine
زبان|Language
فارسی|Persian
خودکار|Auto
فرمت|Format
WebM · رندر مرورگر|WebM · browser render
MP4 · FFmpeg محلی|MP4 · local FFmpeg
شروع خروجی|Start export
توقف خروجی|Cancel export
ساخت تایم‌لاین در افتر|Build timeline in AE
پیش‌نمایش پروژه|Project preview
آماده|Ready
برش، جابه‌جایی و تنظیم کادر|Split, move & transform
متن، زمان‌بندی و استایل هر واژه|Text, timing & individual word styles
ورود، جست‌وجو و اتصال رسانه‌ها|Import, search & relink media
نور، کنتراست و رنگ کلیپ|Clip brightness, contrast & color
ترک‌ها، شدت و فید صدا|Tracks, gain & audio fades
ویدیو، زیرنویس و پروژه|Video, captions & project
بررسی اتصال|Check connection
روشنایی پنل|Panel brightness
خودکار از After Effects|Follow After Effects
روشن|Light
خاکستری روشن|Silver
خاکستری متوسط|Mid gray
تیره|Dark
خیلی تیره|Black
محدودهٔ پیش‌نمایش زنده|Live preview scope
سریع · انتخابی|Fast · selected
کامل · همه متن‌ها|Full · all captions
تنظیمات نمایش|View settings
تنظیمات|Settings
عمومی|General
پیشرفته|Advanced
فعال|Enabled
غیرفعال|Disabled
روشن‌کردن|Start engine
خاموش‌کردن|Stop engine
ساخت موزیک|Music generation
صدا برای هر لحظه|Sound for every moment
مدل تولید|Generation model
نوع صدا|Audio role
موسیقی بی‌کلام|Instrumental music
افکت / Foley|Sound effect / Foley
محیط / Ambience|Ambience
سبک، ریتم و سازبندی|Style, rhythm & instruments
سبک موسیقی|Music style
پیش‌فرض صدا|Sound preset
توصیف خودم|Custom direction
توصیف صدای این بازه|Sound direction for this range
شروع از پلی‌هد|Start at playhead
پایان از پلی‌هد|End at playhead
ثبت بازه و مارکر|Add range & marker
خواندن مارکرها|Read markers
روشن‌کردن موتور|Start engine
ساخت بازه‌ها|Generate ranges
توقف ساخت|Cancel generation
مراحل نمونه‌گیری|Sampling steps
پایبندی به توصیف|Prompt guidance
Seed · منفی یعنی تصادفی|Seed · negative for random
کاربرد / کسب‌وکار|Use case / business
تمپو (BPM)|Tempo (BPM)
ریتم|Rhythm
ضرب|Meter
حس|Mood
انرژی|Energy
سازها / بافت دلخواه|Instruments / texture
سازها / بافت‌های ممنوع|Excluded instruments / texture
سازبندی سفارشی · اختیاری، به‌جای انتخاب خودکار از ژانر|Custom instruments · override genre defaults
تأکید روی کات و مارکر|Cut & marker emphasis
متناسب با سبک|Follow style
متناسب با ژانر|Follow genre
ملایم · پیش‌فرض|Subtle · default
مشخص‌تر|Strong
خاموش|Off
موسیقی|Music
مدل خودکار|Auto model
هماهنگی خودکار با ویدیوی افتر|Sync automatically to the AE video
مسیر مدل‌های موسیقی در تنظیمات|Audio model locations in Settings
نرم|Soft
شناور|Float
کششی|Stretch
جدول|Table
ردیف|Row
ستون|Column
متن|Text
رنگ|Color
استایل|Style
مدت|Duration
زمان|Time
ساخت|Build
پیش‌فرض|Default
بازنشانی|Reset
پیشنهاد|Suggest
بازخوانی|Reload
انتخاب فایل|Choose file
انتخاب پوشه|Choose folder
فایل|File
پوشه|Folder
جست‌وجو|Search
خطا|Error
هشدار|Warning
وضعیت|Status
خروج|Exit
نام|Name
همه متن‌ها|All text
متن انتخاب‌شده|Selected text
حالت|Mode
فاصله|Spacing
دورخط|Stroke
ضخامت|Width
گرادینت|Gradient
سایه|Shadow
محدوده|Range
پیش‌نمایش زنده|Live preview
یکپارچه|Unified
مستقل|Independent
شروع از فریم فعلی|Start at current frame
اعمال به همه|Apply to all
تنظیمات بیشتر|More settings
حافظه|Memory
حذف همه|Delete all
بازگشت|Back
ساخت نمونه|Create sample
رسانه، پیش‌نمایش و تایم‌لاین در یک محیط؛ با یک کلیک به حالت حرفه‌ای برو.|Media, monitor and timeline together. Open the full studio with one click.
ویدیو، تصویر یا صدا را بکش اینجا؛ با دوبار کلیک به تایم‌لاین اضافه می‌شود.|Drop video, images or audio here. Double-click an asset to add it to the timeline.
یک کلیپ را در تایم‌لاین انتخاب کن. رسانه، پیش‌نمایش و تایم‌لاین در همهٔ فضاها کنار هم می‌مانند.|Select a timeline clip. Media, monitor and timeline stay together in every workspace.
رندر مرورگر در زمان واقعی انجام می‌شود. پنجره را باز نگه دار. تصویر و صدای همین تایم‌لاین با زیرنویس و تنظیمات رنگ ذخیره می‌شوند.|Browser export runs in real time. Keep the window visible. The timeline picture, mixed audio, titles and color are included.
فایل پروژه شامل چیدمان و استایل‌هاست؛ رسانه در حافظهٔ همین مرورگر می‌ماند. برای انتقال به دستگاه دیگر فایل‌های اصلی را هم همراه ببر.|Project files contain edits and styles. Media is cached in this browser; include source files when moving to another device.
`.trim().split('\n').map(line=>line.split('|')));
const labels53={"Source": "منبع", "Program": "پیش‌نمایش نهایی", "Selection": "انتخاب", "Razor": "تیغ برش", "Ripple trim": "تریم ریپل", "Rolling edit": "برش رول", "Slip": "لغزش منبع", "Slide": "جابه‌جایی بین دو کلیپ", "Track select": "انتخاب ادامهٔ ترک", "Hand / pan": "جابجایی نما", "Fit sequence": "نمایش کل پروژه", "Mark In · I": "شروع منبع · I", "Mark Out · O": "پایان منبع · O", "Insert · ,": "درج · ,", "Append": "افزودن به انتها", "In · I": "شروع بازه · I", "Out · O": "پایان بازه · O", "Clear In/Out": "پاک‌کردن بازه", "Add marker": "افزودن مارکر", "Import OTIO": "ورود OTIO", "Track height": "ارتفاع ترک", "Sequence preset": "اندازهٔ پروژه", "Close gap": "بستن فاصله", "Text & transcription": "متن و تشخیص گفتار", "Review & translate": "اصلاح و ترجمه", "Typography & words": "تایپوگرافی و واژه‌ها", "Background & glass": "زمینه و شیشه", "Motion": "موشن", "Sound generation": "ساخت صدا", "Build graphics": "ساخت گرافیک", "Models & settings": "مدل‌ها و تنظیمات", "Info & licenses": "اطلاعات و مجوزها", "Save project": "ذخیرهٔ پروژه", "Open project": "بازکردن پروژه", "Preview time": "زمان پیش‌نمایش", "Title": "متن", "Choose a title": "انتخاب متن", "Add title": "افزودن متن", "Transcribe source": "تشخیص گفتار منبع", "Delete title": "حذف متن", "Choose style": "انتخاب استایل", "Size": "اندازه", "Color": "رنگ", "Fill": "رنگ زمینه", "Opacity": "شفافیت", "Corners": "گردی", "Padding": "فاصلهٔ داخلی", "Remove background": "حذف زمینه", "Glass surface": "سطح شیشه‌ای", "Entrance": "انیمیشن ورود", "Translation target": "زبان ترجمه", "Propose spelling corrections": "پیشنهاد اصلاح", "Propose translation": "پیشنهاد ترجمه", "Approve": "تأیید", "Create table": "ساخت جدول", "Width": "عرض", "Height": "ارتفاع", "Divider width": "ضخامت جداکننده", "Divider color": "رنگ جداکننده", "Divider opacity": "شفافیت جداکننده", "Text color": "رنگ متن", "Role": "کاربرد", "Model": "مدل", "Duration": "مدت", "Start engine": "روشن‌کردن موتور", "Music style": "سبک موسیقی", "Instruments": "سازها", "Exclude instruments": "حذف سازها", "Job history": "تاریخچهٔ عملیات", "Cancel this job": "لغو همین عملیات", "Generate": "ساخت", "Brand name": "نام برند", "Save current style": "ذخیرهٔ استایل", "Export brands": "خروجی برندها", "Transparent graphic MOV": "گرافیک شفاف MOV", "Editable Resolve Text+": "متن قابل‌ویرایش داوینچی", "Compatibility": "سازگاری", "Local AI": "هوش مصنوعی محلی", "Task": "کاربرد", "Audio model": "مدل صدا", "Start audio engine": "روشن‌کردن موتور صدا", "Generate / propose": "ساخت / پیشنهاد", "Job history / reconnect": "تاریخچه و اتصال مجدد", "Approve this caption": "تأیید این متن", "Approve identical captions": "اعمال به متن‌های مشابه", "Horizontal alignment": "تراز افقی", "Vertical alignment": "تراز عمودی", "Font": "فونت", "Style": "استایل"};
// Keep technical units and standard initials neutral while translating control labels.
const tablePairs91=Object.fromEntries(`
پیش‌نمایش جدول|Table preview
ساختار جدول|Table structure
متن خانه‌ها و تنظیمات انتخاب|Cell text & selection
ظاهر و حرکت جدول|Table appearance & motion
ویژگی‌های جدول|Properties
تنظیمات خانه|Cell settings
تراز متن خانه‌ها|Cell text alignment
ویرایش ساختار جدول|Edit table structure
خانهٔ فعلی|Current cell
حدود انتخاب|Selection
ردیف|Row
ستون|Column
عرض کلی|Table width
ارتفاع کلی|Table height
جهت جدول|Table direction
RTL — ستون ۱ سمت راست|RTL — column 1 on the right
LTR — ستون ۱ سمت چپ|LTR — column 1 on the left
خودکار بر اساس متن|Auto based on text
Auto بر اساس متن|Auto based on text
شیشهٔ افزوده — سطح مشترک یا خانه‌های مستقل|AE Glass — shared surface or separate cells
اعمال ساختار|Apply structure
افزودن و حذف ردیف یا ستون|Insert or delete rows and columns
ردیف اول یکپارچه|Merge first row
ادغام انتخاب|Merge selection
جداکردن|Unmerge
تنظیمات خانهٔ انتخاب‌شده|Selected cell settings
زمان‌بندی خانه|Cell timing
طبق ریتم جدول|Use table timing
شروع از نشانگر زمان|Start at playhead
زمان دقیق|Custom time
موشن خانه|Cell motion
از جدول|Inherit from table
از خانه|Inherit from cell
بدون موشن|No motion
محو|Fade
بالا آمدن|Rise
تغییر اندازه|Resize
از چپ|Slide left
از راست|Slide right
از بالا|Slide down
جهش|Pop
نرمی ورود|Ease
سریع|Fast
متعادل|Balanced
خیلی نرم|Very smooth
دقیق|Custom
رنگ و قلم همین خانه|Cell color & font
رنگ خانه|Cell fill
رنگ خط|Line color
رنگ متن|Text color
ضخامت خط|Line width
قلم|Font
بازگشت به سبک جدول|Reset to table style
متن همین خانه|Cell text
شروع متن|Text start
همراه خانه|With cell
نشانگر زمان فعلی|Current playhead
از نشانهٔ زمانی|From marker
زمان دستی|Manual time
نشانهٔ زمانی|Marker
نشانهٔ زمانی انتخاب نشده|No marker selected
موشن متن|Text motion
کلمه · بالا|Word · rise
کلمه · آبشاری|Word · cascade
حرف · بالا|Character · rise
خط · بالا|Line · rise
خط · محو|Line · fade
از زمان|From
تا زمان|To
مدت موشن|Motion duration
تراز|Alignment
وسط|Center
راست|Right
چپ|Left
بالا|Top
پایین|Bottom
بالا چپ|Top left
بالا راست|Top right
پایین چپ|Bottom left
پایین راست|Bottom right
محور|Anchor
سایز متن|Text size
زمان دقیق شکل این خانه|Custom cell shape timing
شروع|Start
پایان|End
مدت حضور|Hold duration
مدت ورود|In duration
مدت خروج|Out duration
پیش‌نمایش افتر|AE preview
پیش‌نمایش زنده|Live preview
تازه‌سازی زمان‌بندی|Refresh timing
پاک کردن پیش‌نمایش|Clear preview
ردیف اول عنوان|Header row
ردیف راه‌راه|Alternating rows
شروع جدول|Table start
پایان جدول|Table end
زمینه|Fill
خط|Line
متن|Text
سطح مشترک یکپارچه — یک شیشه برای کل جدول|One surface for the whole table
ورود سطح یکپارچه|Surface entrance
نرم|Smooth
فنری|Spring
شناور|Float
کششی|Stretch
بدون ورود|No entrance
بدون خروج|No exit
فقط ۴ گوشه بیرونی جدول|Outer corners only
همه خانه‌ها گرد|All cells rounded
کاملاً صاف|Square
گردی|Corner radius
گوشه‌های جدول|Table corners
شفافیت خطوط جداکننده|Divider opacity
مرکز افقی|Horizontal center
مرکز عمودی|Vertical center
وسط کامپوزیشن|Center in composition
فونت کل جدول|Table font
همه باهم|Together
ردیفی نرم|Soft row stagger
ستونی نرم|Soft column stagger
سینمایی|Cinematic
محو نرم|Soft fade
بالا آمدن نرم|Soft rise
تغییر اندازه نرم|Soft scale
همزمان|Simultaneous
ورود متن‌ها / خانه‌ها|Text and cell entrance
ترتیب ورود|Entrance order
ریتم ورود|Entrance rhythm
شفافیت خانه‌های مستقل|Cell opacity
شفافیت سطح مشترک|Surface opacity
تنظیمات دقیق ظاهر و ریتم|Appearance & timing
زمان‌بندی دقیق، جای‌گذاری و متریال|Timing, placement & material
اندازهٔ ستون و ردیف انتخاب‌شده|Selected row and column size
عرض نسبی ستون|Column weight
ارتفاع نسبی ردیف|Row weight
ارسال متن خانه‌ها به افتر|Send cell text to AE
پس از خروج از کادر متن|On blur
پس از مکث در نوشتن|After a typing pause
قاب پیش‌نمایش، دست و کلیدهای جهت برای جابه‌جایی|Preview viewport, Pan and arrow keys to move
جای جدول؛ کلیدهای جهت برای جابه‌جایی|Table position. Arrow keys move it
تراز افقی جدول|Horizontal table alignment
تراز عمودی جدول|Vertical table alignment
تراز جدول به چپ قاب|Align table to left edge
مرکز افقی جدول|Center table horizontally
تراز جدول به راست قاب|Align table to right edge
تراز جدول به بالای قاب|Align table to top edge
مرکز عمودی جدول|Center table vertically
تراز جدول به پایین قاب|Align table to bottom edge
متن چپ‌چین|Align text left
متن وسط‌چین|Center text
متن راست‌چین|Align text right
متن بالای خانه|Align text top
متن وسط عمودی خانه|Center text vertically
متن پایین خانه|Align text bottom
فاصله از لبه|Edge margin
متریال شیشهٔ مایع|Liquid glass material
موتور شیشهٔ جدول|Table glass engine
شیشهٔ وارنا|Varna Glass
شیشهٔ اپتیکی|Optical glass
لبهٔ شیشه|Glass rim
ماتی|Frost
انحراف نور|Splay
بزرگ‌نمایی اپتیکی|Magnify
مقیاس افکت|Effect scale
مقیاس لبه|Rim scale
رنگ A|Tint A
رنگ B|Tint B
جهت ترکیب رنگ|Tint angle
عمق لبه|Edge depth
لبهٔ روشن|Bright rim
لبهٔ رنگی|Tinted rim
شکست نرم|Lens
مرکز ترکیب|Tint balance
موج ظریف لبه|Edge wave
عرض تنظیمات|Inspector width
بکش · Shift سریع‌تر · Alt دقیق‌تر|Scrub · Shift faster · Alt for precision
مدت انیمیشن ورود (ثانیه)|Entrance duration (s)
فاصلهٔ ورود (ثانیه)|Entrance spacing (s)
تنظیمات AE Glass جدول|Table AE Glass settings
متریال Liquid Glass جدول|Table liquid glass material
AE Glass — سطح مشترک یا خانه‌های مستقل|AE Glass — shared surface or separate cells
همه Cellها Round|All cells rounded
شروع = Playhead|Start at playhead
پایان = Playhead|End at playhead
شروع = نشانگر زمان|Start at playhead
پایان = نشانگر زمان|End at playhead
آهنربای مرکز و لبه‌ها · Alt برای حرکت آزاد|Snap to center and edges · Alt for free movement
از سبک جدول|Use table style
کد رنگ زمینه|Fill color code
کد رنگ متن|Text color code
کد رنگ خط|Line color code
خواندن فریم واقعی افتر|Read AE frame
شات پشت جدول|Frame behind the table
طراحی تعاملی|Interactive design
فاصلهٔ متن از لبه|Text padding
فاصلهٔ حروف|Tracking
تمیز|Clean
شیشه‌ای|Glass
تیرهٔ حرفه‌ای|Dark Pro
تحریریه‌ای|Editorial
لوکس|Luxury
فناوری|Tech
پخش تلویزیونی|Broadcast
دورخط|Outline
شیشهٔ مایع AE|AE Liquid Glass
شیشهٔ مایع آیفون|iPhone Liquid
شیشهٔ مایع تیره|Dark Liquid
مینیمال|Minimal
آبی داده|Data Blue
کارت نرم|Soft Cards
خودکار|Auto
پیش‌فرض|Default
پایان خانه|Cell end
جای‌گذاری در کامپوزیشن — بکش برای جابه‌جایی؛ گوشه را بکش برای اندازه|Drag to position in the composition. Drag a corner to resize
`.trim().split('\n').map(line=>line.split('|')));
const tableReverse91=Object.fromEntries(Object.entries(tablePairs91).map(([fa,english])=>[english,fa]));
const tableTokens91={Merge:'ادغام',Unmerge:'جداکردن',Cell:'خانه',Shape:'شیپ',Preview:'پیش‌نمایش',Timeline:'زمان‌بندی',Playhead:'نشانگر زمان',Marker:'نشانهٔ زمانی',Fade:'محو',Rise:'بالا آمدن',Scale:'تغییر اندازه','Slide Left':'از چپ','Slide Right':'از راست',Drop:'از بالا',Pop:'جهش',Header:'عنوان',Zebra:'ردیف راه‌راه',Round:'گرد',Draft:'سبک',Full:'کامل'};
function abbreviate91(text){
 return text.replace(/پیکسل|\bpixels?\b/gi,'px')
  .replace(/میلی[‌ ]?ثانیه|\bmilliseconds?\b/gi,'ms')
  .replace(/(·\s*|\(\s*|[\d۰-۹]\s*)ثانیه/g,'$1s')
  .replace(/(·\s*|\(\s*|\d\s*)seconds?\b/gi,'$1s')
  .replace(/فریم[‌ ]*بر ثانیه|frames per second/gi,'fps')
  .replace(/\bdegrees?\b(?=\s*$)/gi,'°').replace(/درصد|\bpercent\b/gi,'%');
}
function tableEnglish91(text){
 if(!/[\u0600-\u06ff]/.test(text))return text;
 const translated=tablePairs91[text]||dictionary[text]||tablePairs91[tablePersian91(text)];
 if(translated)return translated;
 const coordinates=text.match(/^ردیف (\d+) ستون (\d+)$/);
 if(coordinates)return 'Row '+coordinates[1]+', column '+coordinates[2];
 const row=text.match(/^(ردیف|ستون) (\d+(?:\s*\/\s*\d+)?)$/);
 if(row)return (row[1]==='ردیف'?'Row ':'Column ')+row[2];
 if(text.includes(' · '))return text.split(' · ').map(tableEnglish91).join(' · ');
 return english(text);
}
function tablePersian91(text){
 if(text==='Auto based on text'||text==='Auto بر اساس متن')return 'خودکار بر اساس متن';
 let value=tableReverse91[text]||persian53(text);
 if(value===text||/[A-Za-z]/.test(value)){
  for(const [english,fa] of Object.entries(tableTokens91))value=value.replace(new RegExp('\\b'+english+'\\b','g'),fa);
 }
 return value;
}
const persian53=text=>labels53[text]||simplify(text);
const originals=new WeakMap(),attributes=new WeakMap();let lang=localStorage.getItem('VARNA_LANGUAGE52')==='en'?'en':'fa',pending=new Set(),queued=false;
const protectedSelector='#offlineText55,#text55Dialog,script,style,pre,code,textarea,input,canvas,#varnaInfo47,#wordList,#reviewText,#correctionTextPreview,.caption-row,.scene-piece40,.scene-preview40,.preview-text50,#tableEditor,#tablePreview,#brandList,#brandAssetsList,#brandShortcut,#startupBrandSelect49,#brollFiles,.edit51-bin,.edit51-caption-list,.edit51-word,.edit51-clip,#fontSelect,#cellFontPS,#modelSelect,[data-user-content]';
function simplify(text){return text.replace(/\s+وارنا(?=\s|$)/g,'').replace(/^وارنا\s+(?=استودیو)/,'').trim();}
function english(text){const simple=simplify(text);if(dictionary[text]||dictionary[simple])return dictionary[text]||dictionary[simple];if(text.includes(' · '))return text.split(' · ').map(english).join(' · ');return simple.replace(/(\d+)\s*ثانیه/g,'$1 s').replace(/(\d+)\s*مورد/g,'$1 items').replace(/(\d+)\s*کپشن/g,'$1 captions');}
function localizeLabel91(label,element){
 const table=element?.closest('#page-table');
 return abbreviate91(lang==='en'?(table?tableEnglish91(label):english(label)):(table?tablePersian91(label):persian53(label)));
}
function translate(root=document.body){if(!root||root.closest?.(protectedSelector))return;const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let node;while((node=walker.nextNode())){if(node.parentElement?.closest(protectedSelector))continue;const current=node.nodeValue,record=originals.get(node);let raw=record&&current===record.last?record.raw:current;if(!raw.trim())continue;const space=raw.match(/^\s*/)[0],trail=raw.match(/\s*$/)[0],label=raw.trim(),value=space+localizeLabel91(label,node.parentElement)+trail;originals.set(node,{raw,last:value});if(value!==current)node.nodeValue=value;}
for(const el of root.querySelectorAll?.('[title],[placeholder],[aria-label]')||[]){if(el.closest('script,style,#varnaInfo47,[data-user-content]'))continue;const records=attributes.get(el)||{};for(const attr of ['title','placeholder','aria-label']){const current=el.getAttribute(attr);if(current==null)continue;const record=records[attr],raw=record&&current===record.last?record.raw:current,value=localizeLabel91(raw,el);records[attr]={raw,last:value};if(value!==current)el.setAttribute(attr,value);}attributes.set(el,records);}}
function set(value){lang=value==='en'?'en':'fa';localStorage.setItem('VARNA_LANGUAGE52',lang);document.documentElement.lang=lang;document.documentElement.dir=lang==='en'?'ltr':'rtl';document.body.dataset.language52=lang;translate();document.querySelectorAll('button[data-language52]').forEach(b=>b.textContent=lang==='en'?'فارسی':'English');document.dispatchEvent(new CustomEvent('varna:language52',{detail:{language:lang}}));}
function addSwitch(root){if(root.querySelector('[data-language52]'))return;const b=document.createElement('button');b.type='button';b.dataset.language52='true';b.className='language52';b.textContent=lang==='en'?'فارسی':'English';b.onclick=()=>set(lang==='en'?'fa':'en');root.append(b);}
new MutationObserver(records=>{for(const r of records){const el=r.target.nodeType===1?r.target:r.target.parentElement;if(el&&!el.closest(protectedSelector))pending.add(el);}if(!queued){queued=true;setTimeout(()=>{queued=false;const roots=[...pending];pending.clear();for(const root of roots)translate(root);document.querySelectorAll('.edit51-head .edit51-actions').forEach(addSwitch);},40);}}).observe(document.body,{childList:true,subtree:true,characterData:true});
const holder=document.querySelector('#headerOptions .header-options-panel');if(holder)addSwitch(holder);document.querySelectorAll('.edit51-head .edit51-actions').forEach(addSwitch);w.VarnaI18n52={set,translate,language:()=>lang,dictionary};set(lang);
})(window);
