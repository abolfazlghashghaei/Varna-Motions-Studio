﻿param(
    [string]$Target = (Join-Path $env:APPDATA 'Adobe\CEP\extensions\VarnaMotionStudio'),
    [switch]$Rollback
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Get-Hash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-BytesHash([byte[]]$Bytes) {
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha256.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha256.Dispose() }
}

function Set-PanelFile([string]$Path, [byte[]]$Bytes) {
    $parent = Split-Path -Parent $Path
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $pending = $Path + '.ui91-' + [guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllBytes($pending, $Bytes)
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($pending, $Path, [NullString]::Value) }
        else { [IO.File]::Move($pending, $Path) }
    } finally {
        if ([IO.File]::Exists($pending)) { [IO.File]::Delete($pending) }
    }
}

function Restore-PanelFile($Entry) {
    $path = Join-Path $Target $Entry.path
    if ($Entry.existed) { Set-PanelFile $path ([IO.File]::ReadAllBytes((Join-Path $backup $Entry.path))) }
    elseif ([IO.File]::Exists($path)) { [IO.File]::Delete($path) }
}

$lock = $null
try {
    if (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) {
        throw 'Close After Effects and run the update again.'
    }
    if (!(Test-Path -LiteralPath $Target -PathType Container)) {
        throw "Varna folder not found: $Target. For a custom installation, pass its folder with -Target."
    }
    $Target = (Get-Item -LiteralPath $Target).FullName
    $manifestPath = Join-Path $Target 'PACKAGE_MANIFEST.json'
    $indexPath = Join-Path $Target 'index.html'
    $extensionPath = Join-Path $Target 'CSXS\manifest.xml'
    if (!(Test-Path -LiteralPath $manifestPath -PathType Leaf) -or !(Test-Path -LiteralPath $extensionPath -PathType Leaf)) {
        throw 'The target must be an installed or extracted Varna Motion Studio UI85.1 (with or without engine) folder.'
    }
    [xml]$extension = [IO.File]::ReadAllText($extensionPath)
    if ($extension.ExtensionManifest.ExtensionBundleId -ne 'com.varnalabs.motionstudio') { throw 'This is not the Varna After Effects extension.' }

    $lockPath = Join-Path $Target '.varna-ui-update.lock'
    $lock = [IO.FileStream]::new($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None, 4096, [IO.FileOptions]::DeleteOnClose)
    $backup = Join-Path $Target '.varna-ui91-merged-backup'
    $backupRecord = Join-Path $backup 'files.json'
    $spec = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'update-manifest.json')) | ConvertFrom-Json
    $package = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    $baseUi = [string]$package.ui
    if ([string]::IsNullOrWhiteSpace($baseUi) -and $spec.bases.'85'.indexHashes -contains (Get-Hash $indexPath)) { $baseUi = '85' }
    $base = $spec.bases.PSObject.Properties[$baseUi]
    $uiFiles = @($spec.files | ForEach-Object { $_.path })
    $pathsChanged = $uiFiles + @('index.html')
    $targets = $pathsChanged + @('PACKAGE_MANIFEST.json')
    $index = [IO.File]::ReadAllText($indexPath)

    if ($Rollback) {
        if (!(Test-Path -LiteralPath $backupRecord -PathType Leaf)) {
            if ($base -and $index -notmatch '\bdata-ui91\b') { Write-Host 'The previous UI is already active.'; exit 0 }
            throw 'The local UI91 update backup is required.'
        }
        $saved = @([IO.File]::ReadAllText($backupRecord) | ConvertFrom-Json)
        $recordPaths = @($saved | ForEach-Object { $_.path })
        if (@(Compare-Object -ReferenceObject $targets -DifferenceObject $recordPaths).Count) { throw 'The local backup does not match this release.' }
        $restore = @()
        foreach ($entry in $saved) {
            $file = Join-Path $Target $entry.path
            if ($entry.existed -and (Get-Hash (Join-Path $backup $entry.path)) -ne $entry.originalHash) { throw "Backup checksum mismatch: $($entry.path)" }
            $hash = if ([IO.File]::Exists($file)) { Get-Hash $file } else { '' }
            if ($hash -eq $entry.originalHash) { continue }
            if ($hash -ne $entry.installedHash) { throw "A UI91 file changed after installation: $($entry.path). Keep the backup and restore manually." }
            $restore += $entry
        }
        if (!$restore.Count) { Write-Host 'The previous UI is already active.'; exit 0 }
        $current = @{}
        foreach ($entry in $restore) { $current[$entry.path] = [IO.File]::ReadAllBytes((Join-Path $Target $entry.path)) }
        $done = @()
        try {
            foreach ($entry in $restore) { Restore-PanelFile $entry; $done += $entry }
        } catch {
            foreach ($entry in $done) { Set-PanelFile (Join-Path $Target $entry.path) $current[$entry.path] }
            throw
        }
        Write-Host 'Restored the previous UI. Reopen After Effects.'
        exit 0
    }

    if ($package.ui -eq 91 -and $index -match '\bdata-ui91\b') {
        $byPath = @{}
        foreach ($entry in $package.files) { $byPath[[string]$entry.path] = $entry.sha256 }
        foreach ($relative in $pathsChanged) {
            if ((Get-Hash (Join-Path $Target $relative)) -ne $byPath[$relative]) { throw "UI91 checksum mismatch: $relative" }
        }
        Write-Host 'UI91 is already active.'
        exit 0
    }
    if (!$base -or $package.version -ne $spec.baseVersion) { throw 'This update requires Varna Motion Studio 4.5 RC47 with UI85.1 (with or without engine).' }
    foreach ($relative in $spec.requiredAssets) {
        if (!(Test-Path -LiteralPath (Join-Path $Target $relative) -PathType Leaf)) {
            throw "Required asset missing: $relative. Use the complete Varna installation, including its assets folder."
        }
    }
    $profile = $base.Value
    if ($profile.indexHashes -notcontains (Get-Hash $indexPath)) { throw "This index.html is different from the supported UI$baseUi installation profiles." }
    $newIndex = $index.Replace($profile.indexMarker, $spec.newIndexMarker).Replace($profile.styleAnchor, $profile.styleReplacement)
    if ($newIndex -eq $index) { throw "The UI$baseUi panel markup could not be updated." }
    $writes = @{'index.html' = $utf8.GetBytes($newIndex)}
    foreach ($entry in $spec.files) {
        $local = Join-Path $Target $entry.path
        $incoming = Join-Path (Join-Path $PSScriptRoot 'payload') $entry.path
        if ((Get-Hash $incoming) -ne $entry.sha256) { throw "Update archive checksum mismatch: $($entry.path). Extract the ZIP again." }
        $baseHash = $entry.baseHashes.PSObject.Properties[$baseUi].Value
        if ($baseHash) {
            if ((Get-Hash $local) -ne $baseHash) { throw "This file is different from UI$baseUi`: $($entry.path)" }
        } elseif ([IO.File]::Exists($local)) { throw "An unexpected existing file would be overwritten: $($entry.path)" }
        $writes[$entry.path] = [IO.File]::ReadAllBytes($incoming)
    }
    $indexDigest = Get-BytesHash $writes['index.html']
    $entries = @($package.files | Where-Object { $pathsChanged -notcontains $_.path })
    foreach ($entry in $spec.files) { $entries += [PSCustomObject]@{path = $entry.path; bytes = $entry.bytes; sha256 = $entry.sha256} }
    $entries += [PSCustomObject]@{path = 'index.html'; bytes = $writes['index.html'].Length; sha256 = $indexDigest}
    $package.files = @($entries | Sort-Object -Property path)
    $package | Add-Member -NotePropertyName ui -NotePropertyValue 91 -Force
    $writes['PACKAGE_MANIFEST.json'] = $utf8.GetBytes(($package | ConvertTo-Json -Depth 8 -Compress) + "`n")

    if (Test-Path -LiteralPath $backup) {
        $previous = $backup + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
        Move-Item -LiteralPath $backup -Destination $previous
    }
    New-Item -ItemType Directory -Path $backup | Out-Null
    $saved = @()
    foreach ($relative in $targets) {
        $file = Join-Path $Target $relative
        $existed = [IO.File]::Exists($file)
        $originalHash = ''
        if ($existed) {
            $copy = Join-Path $backup $relative
            New-Item -ItemType Directory -Path (Split-Path $copy -Parent) -Force | Out-Null
            [IO.File]::Copy($file, $copy)
            $originalHash = Get-Hash $copy
        }
        $saved += [PSCustomObject]@{path = $relative; existed = $existed; originalHash = $originalHash; installedHash = (Get-BytesHash $writes[$relative])}
    }
    [IO.File]::WriteAllText($backupRecord, ($saved | ConvertTo-Json -Depth 3), $utf8)
    $done = @()
    try {
        foreach ($entry in $saved) {
            $file = Join-Path $Target $entry.path
            Set-PanelFile $file $writes[$entry.path]
            $done += $entry
            if ((Get-Hash $file) -ne $entry.installedHash) { throw "Verification failed after writing: $($entry.path)" }
        }
    } catch {
        foreach ($entry in $done) { Restore-PanelFile $entry }
        throw
    }
    Write-Host 'Varna Motion Studio UI91 with the original interactive V is ready. Reopen After Effects.'
    Write-Host "Previous UI backup: $backup"
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
} finally {
    if ($lock) { $lock.Dispose() }
}
