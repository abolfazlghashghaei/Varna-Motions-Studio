@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-VarnaUI.ps1" %*
set "VARNA_UI_RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %VARNA_UI_RESULT%
