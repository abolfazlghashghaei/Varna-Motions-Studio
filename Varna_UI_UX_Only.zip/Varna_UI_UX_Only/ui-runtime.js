/* Standalone design interactions only. No host bridge, networking or processing. */
(function(){'use strict';
 const D=window.VarnaDesignData,$=s=>document.querySelector(s),all=s=>[...document.querySelectorAll(s)];
 let route='home',language='fa',theme='dark',palette='original',band='',collapsed=false,frameKey='',toastTimer=0;
 const pins=new Set(['audio','text','motion','bg','table']),forms=new Map();
 const t=(fa,en)=>language==='en'?en:fa;
 function notice(){let n=$('#designNotice');if(!n){n=document.createElement('div');n.id='designNotice';n.setAttribute('role','status');Object.assign(n.style,{position:'fixed',insetInline:'1rem',bottom:'4rem',padding:'.75rem',border:'1px solid var(--ui-color-border)',background:'var(--ui-color-surface)',color:'var(--ui-color-text)',zIndex:'99999',borderRadius:'.4rem',font:'12px/1.6 sans-serif',pointerEvents:'none'});document.body.append(n);}n.textContent=t('این نسخه فقط رابط کاربری است؛ پردازش یا اعمال روی افتر انجام نمی‌شود.','UI/UX design only: processing and After Effects actions are not included.');n.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.hidden=true,2800);}
 function paint(){const p=D.palettes[theme+':'+palette];document.body.setAttribute('style',p.style);document.body.dataset.theme=p.theme;document.body.dataset.uiColorScheme68=p.scheme;document.body.dataset.themeMode=theme;all('[data-palette77]').forEach(n=>n.setAttribute('aria-pressed',n.dataset.palette77===palette));const s=$('#uiTheme');if(s)s.value=theme;}
 function preserve(){const out={};all('#workspace input[id],#workspace select[id],#workspace textarea[id]').forEach(n=>out[n.id]={value:n.value,checked:n.checked});forms.set(language+':'+route,out);}
 function size(){const shell=$('.app-shell');if(!shell)return;const width=innerWidth;shell.dataset.size=width<340?'compact':width<=640?'normal':'wide';shell.dataset.panelBand69=shell.dataset.size;shell.dataset.panelMicro69=String(width<280);shell.dataset.panelShort71=String(innerHeight<480);shell.dataset.dockCollapsed77=String(collapsed);shell.dataset.railMode79=collapsed||width<1120||innerHeight<650?'icons':'labels';shell.style.setProperty('--flow-rail77',shell.dataset.railMode79==='icons'?'3rem':'5.6rem');
  all('.pane-workspace84').forEach(root=>{const r=$('#workspace').getBoundingClientRect(),wide=r.width>=740&&r.height>=430;root.dataset.paneLayout84=wide?'wide':'stacked';if(root.closest('.text-panels84')){root.style.height=Math.max(320,r.height-8)+'px';return;}root.style.height=wide?Math.max(160,r.height-Math.max(0,root.getBoundingClientRect().top-r.top)-4)+'px':'';});
 }
 function navigate(next=route,force=false){if(!D.routes.includes(next))next='home';preserve();route=next;const nextBand=innerWidth<340?'compact':innerWidth<820||innerHeight<480?'normal':'wide',key=language+':'+nextBand;
  if(force||key!==frameKey){document.body.innerHTML=D.frames[key].html;frameKey=key;band=nextBand;}
  const view=D.views[key+':'+route];for(const [name,value]of Object.entries(view.body))document.body.setAttribute(name,value);
  document.documentElement.lang=language;document.documentElement.dir=language==='en'?'ltr':'rtl';$('#workspace').innerHTML=view.html;$('#workspace').scrollTop=0;$('#currentPageTitle').textContent=view.title;$('.flat-actions69').outerHTML=view.actions;
  const saved=forms.get(language+':'+route)||{};for(const[id,state]of Object.entries(saved)){const n=document.getElementById(id);if(n){n.value=state.value;n.checked=state.checked;}}
  all('.flat-nav69 [data-page69]').forEach(n=>{const selected=n.dataset.page69===route;n.setAttribute('aria-current',String(selected));n.classList.toggle('active',selected);n.hidden=!['home','output'].includes(n.dataset.page69)&&!pins.has(n.dataset.page69);});
  const identity=$('.flow-identity78>span');if(identity)identity.textContent='UI / UX · DESIGN ONLY';
  paint();size();if(location.hash.slice(1)!==route)history.replaceState(null,'','#'+route);
 }
 function dialog(selector){const n=$(selector);if(n&&!n.open)n.showModal();}
 function maximize(button){const pane=button.closest('.pane84');if(!pane)return;const host=pane.closest('.pane-workspace84')?.parentElement,dialogNode=host?.querySelector('.pane-fullscreen84');if(!dialogNode)return;const mark=document.createComment('design-pane');pane.before(mark);const old=pane.getAttribute('style');dialogNode.append(pane);pane.dataset.maximized84='true';pane.style.height='100%';dialogNode.showModal();const restore=()=>{mark.replaceWith(pane);if(old===null)pane.removeAttribute('style');else pane.setAttribute('style',old);delete pane.dataset.maximized84;dialogNode.removeEventListener('close',restore);};dialogNode.addEventListener('close',restore);}
 document.addEventListener('click',e=>{
  const b=e.target.closest('button,a');if(!b)return;
  const d=b.dataset;
  if(b.closest('.pane-fullscreen84')&&b.classList.contains('pane-action84')){b.closest('dialog').close();return;}
  if(b.classList.contains('pane-action84')&&/Maximize|تمام|بزرگ/i.test(b.title)){maximize(b);return;}
  const destination=d.page69||d.destination69||d.launch||d.task77||d.page||(d.collection84?'library-'+d.collection84:null);
  if(destination&&D.routes.includes(destination)){e.preventDefault();all('dialog[open]').forEach(n=>n.close());navigate(destination);return;}
  if(b.matches('[data-flow-logo77]')){navigate('home');return;}
  if(b.matches('[data-more69],[data-customize77]')||b.id==='studio30Search'){dialog('.flat-chooser69');return;}
  if(b.matches('.flow-catalog-close77')||b.closest('.font-dialog67')&&b.textContent.trim()==='×'){b.closest('dialog').close();return;}
  if(b.matches('[data-collapse77]')){collapsed=!collapsed;size();return;}
  if(d.side77){$('.app-shell').dataset.dockSide77=d.side77;return;}
  if(d.pin77){pins.has(d.pin77)?pins.delete(d.pin77):pins.add(d.pin77);navigate(route);dialog('.flat-chooser69');return;}
  if(d.palette77){palette=d.palette77;paint();return;}
  if(b.matches('[data-language52], [data-language-toggle52]')||['English','فارسی'].includes(b.textContent.trim())){preserve();language=language==='fa'?'en':'fa';navigate(route,true);return;}
  if(b.id==='btnGoOutput'){navigate('output');return;}
  if(b.id==='homeShortcut'){navigate('home');return;}
  if(b.id==='brandShortcut'){navigate('brand');return;}
  if(b.matches('[data-primary69]')&&['home','tools'].includes(route)){dialog('.flat-chooser69');return;}
  if(b.matches('.text80-settings')){dialog('.text-inspector-dialog80');return;}
  if(b.matches('[data-close-modal],.modal-close')){const modal=b.closest('.ghaf-modal,dialog');if(modal?.tagName==='DIALOG')modal.close();else if(modal)modal.hidden=true;return;}
  if(b.closest('dialog')&&/بستن|Close/.test(b.textContent)){b.closest('dialog').close();return;}
  if(b.matches('.bg-tabs81 [role=tab]')){const motion=[...b.parentElement.children].indexOf(b)===1;[...b.parentElement.children].forEach(n=>n.setAttribute('aria-selected',String(n===b)));$('.bg-look81').hidden=motion;$('.bg-motion81').hidden=!motion;size();const pane=$('.bg-motion81 .pane-main84>.pane84');if(motion&&pane)pane.style.height=Math.max(200,$('#workspace').clientHeight-70)+'px';return;}
  if(b.matches('.flow-header-button77')&&b.title){const details=$('#headerOptions');if(details){details.open=!details.open;return;}}
  // Keep preset selection visible, while never claiming a generated result.
  if(b.matches('.asset-card84,.motion-preset,.feature-card83,[data-anim-preset]')){const group=b.parentElement;group.querySelectorAll('.active,[aria-pressed=true]').forEach(n=>{n.classList.remove('active');n.setAttribute('aria-pressed','false');});b.classList.add('active');b.setAttribute('aria-pressed','true');}
  if(!b.matches('[data-close-modal]')){e.preventDefault();notice();}
 });
 document.addEventListener('change',e=>{const n=e.target;if(n.id==='uiTheme'){theme=['light','silver'].includes(n.value)?'light':'dark';paint();}if(n.id==='themePreset50'){palette=D.palettes[theme+':'+n.value]?n.value:'original';paint();}});
 document.addEventListener('input',e=>{const n=e.target;
  if(n.matches('[data-catalog-search77]')){const q=n.value.toLowerCase();all('.flow-catalog-row77,.flow-catalog-row78,.flat-chooser-grid69>button').forEach(row=>row.hidden=!row.textContent.toLowerCase().includes(q));}
  if(n.type==='range'){const parent=n.closest('.numeric37,.numeric-control37');const field=parent?.querySelector('input[type=number]');if(field)field.value=n.value;}
  if(n.matches('[data-blur77]'))document.body.style.setProperty('--flow-bg-blur77',n.value+'px');
 });
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();dialog('.flat-chooser69');}if(e.key==='Escape')all('dialog[open]').forEach(n=>n.close());});
 let frame=0;addEventListener('resize',()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>navigate(route));});addEventListener('hashchange',()=>navigate(location.hash.slice(1)));
 window.VarnaDesign={open:n=>navigate(n),routes:D.routes,setLanguage(lang){language=lang==='en'?'en':'fa';navigate(route,true);},setTheme(value){theme=value==='light'?'light':'dark';paint();},current:()=>route};
 navigate(location.hash.slice(1)||'home',true);
})();
